# Date Created: 3/26/2025 8:52 AM
# Last Modified:3/27/2025 8:13 PM
# Author: Dani Lopez
 
# Usage Instructions and Description:
#   Prior to running this program, please make sure to have the following libraries/packages installed
#       - pandas
#       - matplotlib
#       - scipy
#       - python-docx
#   This program takes no arguments.
#   Run the program and it will output the following files into the working directory
#       - frequency.csv
#           - contains a table with frequency percentage information for each cell type in each sample
#       - frequency_analysis.docx
#           - a rough draft document containing:
#               - a descriptive title
#               - boxplots for each cell-type: compares frequency of the cell type in PBMC samples taken 0 days from tr1 treatment start
#                 in responding and non-responding melanoma patients
#               - brief figure captions for each plot containing mean and standard error for each group, p-value, and the type of test used to determine the pvalue
#       -.png files for each boxplot       

import pandas as pd
import os
import matplotlib.pyplot as plt
from scipy.stats import mannwhitneyu
from scipy.stats import sem
from docx import Document
from docx.shared import Inches

print("\nStarting cell-count.csv processing program...")

# Set working directory
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Read in cell-count.csv as a dataframe
cell_df = pd.read_csv("cell-count.csv")

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------
# PART 1 - cell_count.csv -> frequency.csv
#-----------------------------------------------------------------------------------------------------------------------------------------------------------------

# Obtain total count of cell types and add to data frame
cell_types = ["b_cell", "cd8_t_cell", "cd4_t_cell", "nk_cell", "monocyte"]
cell_df["total_count"] = cell_df[cell_types].sum(axis = 1)

# Create new data frame to hold frequency data
frequency_df = pd.DataFrame()

# Initialize empty lists to hold column data
sample_col = []
total_count_col = []
population_col = []
count_col = []

# Populate lists with data for frequency data frame columns
for row in range(len(cell_df)):                                                                     # for each sample                                                         
    for type in cell_types:                                                                             # for each cell type in the sample
        sample_col.append(cell_df.iloc[row, cell_df.columns.get_loc("sample")])                             # enter sample id
        total_count_col.append(cell_df.iloc[row, cell_df.columns.get_loc("total_count")])                   # enter total number of cells
        population_col.append(type)                                                                         # enter the cell type
        count_col.append(cell_df.iloc[row, cell_df.columns.get_loc(type)] )                                 # enter the count for that cell type

# Place the lists in the frequency data frame as columns
frequency_df["sample"] = sample_col
frequency_df["total_count"] = total_count_col
frequency_df["population"] = population_col
frequency_df["count"] = count_col
# Calculate percentage column
frequency_df["percentage"] = (frequency_df["count"]/frequency_df["total_count"]) * 100
        
# Save frequency data frame to csv        
frequency_df.to_csv("frequency.csv", index = False)

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------
# PART 2 - Data Analysis and Visualization - Cell type frequencies in responders and non responders receiving 
#-----------------------------------------------------------------------------------------------------------------------------------------------------------------

# Filter data to only include only include PBMC samples taken 0 days from treatment start from subjects on tr1 treatment for melanoma
tr_response_df = cell_df[(cell_df["treatment"] == "tr1") 
                         & (cell_df["sample_type"] == "PBMC") 
                         & (cell_df["condition"] == "melanoma") 
                         & (cell_df["time_from_treatment_start"] == 0)]

# Separate dataframes for responders and non responders
tr_responders = tr_response_df[tr_response_df["response"] == "y"] 
tr_nonresponders = tr_response_df[tr_response_df["response"] == "n"] 

# Create document to hold data visualizations and statistics
doc = Document()
doc.add_heading("Comparison of WBC type frequencies between responders and non-responders on Day 0 of tr1 treatment for melanoma", 0)

# Create plot, collect statistics, and add to analysis document for each cell type
i = 0  #count iterations                                                           
for type in cell_types:

    # Generate plot
    plt.figure(figsize=(8, 6))
    tr_responders_freq = (tr_responders[type]/tr_responders["total_count"]) * 100               # Generate y axis frequency data for responders
    tr_nonresponders_freq = (tr_nonresponders[type]/tr_nonresponders["total_count"]) * 100      # Generate y axis frequency data for non-responders
    plt.boxplot([tr_responders_freq,tr_nonresponders_freq])

    # Annotate plot
    plt.title(type + " frequency in responders and non-responders")                                                                            
    plt.xlabel("response")                                                                      
    plt.xticks([1, 2], ["responders", "non-responders"])
    plt.ylabel(type + " frequency (%)")                                                                     
    plt.savefig(type + "_frequency_plot.png")

    # Collect statistics
    mean_responders = tr_responders_freq.mean()
    mean_nonresponders = tr_nonresponders_freq.mean()
    std_err_responders = sem(tr_responders_freq)
    std_err_nonresponders = sem(tr_nonresponders_freq)
    ustat, p_value = mannwhitneyu(tr_responders_freq, tr_nonresponders_freq)

    # Add figure and caption into document
    doc.add_picture(type + "_frequency_plot.png", width=Inches(7)) 
    par_str = "Figure " + str(i+1) + ". Responder (n = " + str(len(tr_responders)) + ") vs non-responder (n = " + str(len(tr_nonresponders)) + ") statistics for " + type + " frequency: " + f"{mean_responders:.3f}" + " ± " + f"{std_err_responders:.3f}" + " vs " + f"{mean_nonresponders:.3f}" + " ± " + f"{std_err_nonresponders:.3f}" + "; p = " + f"{p_value:.3f}" + ", Mann-Whitney U-Test"
    doc.add_paragraph(par_str)

    i += 1  #increment loop counter
 
# Save document
doc.save("frequency_analysis.docx")

print("Program is complete.\nfrequency.csv, frequency_analysis.docx, and .png files for each boxplot can be found in the current directory.\n")
    
